export const VwType = {
    graph: 1,
    clss: 2,
}