# Code Explorer — lộ trình gộp 3 project

Gộp **mind-map** (nền), **code-viewer** và **class-diagram** thành một ứng dụng khám phá mã nguồn:

```
Tổng quan (project)  →  Project (file)  →  File (class + thành viên)
     mind-map              mind-map            class-diagram
                     Editor / tìm kiếm: code-viewer
```

## Trạng thái

| Mốc | Nội dung | Trạng thái |
| --- | --- | --- |
| **M0** | Tách `App.vue` của mind-map, dựng store | **Xong**, đã thử tay |
| **M1** | Lõi chung: `core/path.js`, `ignore-rules.js`, `source.js`, `mask-comments.js` | **Xong**, đã thử tay |
| **M2** | Editor chỉ đọc: bấm node → mở file trong panel bên phải (Monaco tải lười), kéo thanh chia đôi, "Ẩn comment" | **Xong** — 31 test + kiểm tra tĩnh qua; **chưa build/chạy thật** (xem checklist M2 cuối file) |
| M3 | Danh sách file (Explorer, chip đuôi file) + tìm kiếm tên / symbol / nội dung (Worker), làm nổi bật node, tô sáng kết quả trong editor | Chưa |
| M4 | Dải "Dùng / Được dùng bởi" trong editor, nhảy tới dòng định nghĩa | Chưa |
| M4b | Sơ đồ class (**C# trước**, Java sau) cho các file đang chọn | Chưa |
| M5 | Sửa và lưu ra đĩa, phân tích lại từng file | Chưa |

## Bản đồ: mã của hai project kia sẽ vào đâu

| Nguồn | Đích | Thay đổi cần làm |
| --- | --- | --- |
| code-viewer `components/CodeEditor.vue` | `features/editor/EditorPanel.vue` (**đã làm ở M2**, bản chỉ đọc) | Bỏ sửa/lưu/tải về (để M5), nạp Monaco lười, đọc qua `workspace.readFile`. Phần `query` tô sáng từ khoá → M3 |
| code-viewer `App.vue` (sidebar, chip đuôi file, tìm kiếm) | `features/explorer/` + `search/search.worker.js` | Chuyển tìm nội dung sang Worker; thêm tìm theo symbol |
| code-viewer `utils/stripComments.js` | `core/mask-comments.js` (**đã chuyển ở M1**) | Nối vào nút "Dọn comment" của editor ở M2 |
| code-viewer `utils/file.js` (`formatSize`…) | `utils/` | Lấy khi cần ở M2 |
| class-diagram `utils/csharp.js` | `features/diagram/parsers/csharp.js` | Thêm `line`; id class = tên đầy đủ (namespace + tên); che comment giữ nguyên độ dài |
| class-diagram `utils/diagram.js` | `features/diagram/layout.js` | Giữ nguyên (hàm thuần) |
| class-diagram `ClassBox.vue`, `DiagramsView.vue`, `stores/diagram.js` | `features/diagram/` | Bỏ panel Source riêng; store đổi từ "một đoạn source" sang "tập file đang chọn"; khoá vị trí theo (file + class) |
| class-diagram `MonacoEditor.vue`, `Icon.vue` | (bỏ) | Dùng chung editor và bootstrap-icons |

## Quyết định đã chốt

- Làm trên bản sao mới, không sửa hai project gốc; JavaScript (không TypeScript).
- v1 **chỉ đọc**; sửa/lưu ra đĩa để M5.
- **Một bộ quy tắc lọc file** (`core/ignore-rules.js`) = bộ của analyzer. Danh sách trắng đuôi file của code-viewer **bỏ**: mọi thư mục nó loại đều đã được bộ chung loại, còn đuôi lạ (`.csproj`, `.ps1`…) giờ hiển thị như văn bản thường. Hai giới hạn kích thước tách rõ: phân tích 1 MB (`MAX_ANALYZE_SIZE`), xem trong editor 5 MB (`MAX_VIEW_SIZE`).
- **Path do `core/source.js` quyết định, ngay trên luồng chính**: chuẩn hoá và gỡ tên thư mục gốc rồi mới gửi sang Worker (Worker không gỡ nữa). Nhờ vậy `node.file` ≡ khoá của `source.read(path)` ở cả Chrome/Edge lẫn Firefox/Safari.
- **Bộ che comment: đã gom về một module + một bộ test, CHƯA gộp vòng quét.** `maskComments` (giữ nguyên vị trí) và `stripComments` (xoá hẳn) có hợp đồng khác nhau. Gộp thành một bộ quét là việc của M4b, làm theo kiểu "golden master" (so với hai bản cũ trên mọi file thật) vì parser class cần che chuỗi C# verbatim `@"…"` mà `maskComments` hiện chưa hiểu; lúc đó `clean()` của class-diagram cũng được thay.
- **Editor (M2)**: chỉ đọc; Monaco nạp bằng `import()` ở lần mở file đầu tiên; mỗi file một model (tối đa 24, bỏ cái lâu chưa dùng) và nhớ vị trí cuộn; bỏ chọn trên sơ đồ thì panel **giữ file đang xem**; chọn lại đúng node đang chọn thì mở lại panel (`selection.tick`); mở thư mục khác thì panel đóng. Độ rộng panel được nhớ (localStorage) và luôn chừa tối thiểu 280 px cho sơ đồ.
- **"Ẩn comment"** chỉ đổi cách hiển thị (`stripComments` với đuôi file thật — code-viewer cũ luôn truyền `'cs'` cho mọi file), không đổi file; bản đã ẩn comment dùng model riêng.
- **Theme editor đang cố định sáng** (cả ứng dụng còn ghi cứng màu sáng); chuyển sang bảng màu sáng/tối chung ở bước `styles/tokens.css`.
- **Không nạp nội dung file vào luồng chính.** Giữ handle/File, đọc theo yêu cầu (giữ khả năng chịu hàng chục nghìn file của mind-map).
- Một quy ước path duy nhất; `stores/selection.js` là nguồn sự thật cho "đang chọn gì" (sơ đồ file, editor, sơ đồ class cùng đọc/ghi).
- Sơ đồ class: **chỉ hiện class của file đang chọn**, parse **theo yêu cầu** (không nhét vào pipeline toàn dự án), giới hạn ~50-60 class mỗi sơ đồ. Không làm "thêm lớp liên quan" ở bản đầu.
- Sơ đồ class là chế độ xem riêng (DOM + SVG, tab chuyển với sơ đồ file), không vẽ trên Sigma.
- Monaco và `features/diagram` tải lười để màn hình sơ đồ file vẫn nhẹ. Cấu hình Monaco = hợp của hai project (css/html/json/typescript + csharp/java).
- Một bộ màu sáng/tối chung (`styles/tokens.css`) — hiện mind-map còn ghi cứng màu sáng.
- **Java để sau** (viết `parsers/java.js` theo "hồ sơ ngôn ngữ" gần giống C#).

## Cấu trúc hiện tại (sau M2)

```
src/
├── main.js, style.css        # style.css chứa kiểu nút dùng chung
├── App.vue                   # chỉ còn layout: TopBar + GraphView
├── components/               # TopBar, SplitHandle (thanh kéo chia đôi)
├── stores/
│   ├── workspace.js          # thư mục đang mở, kết quả phân tích, cầu nối Worker (không biết Sigma)
│   ├── graph.js              # Sigma/graphology: vẽ, làm nổi bật, lọc node, bảng thông tin
│   ├── settings.js           # includeVendor, hình dạng node (localStorage)
│   ├── selection.js          # file/node đang chọn (+ tick)  ← khớp nối cho editor và sơ đồ class
│   └── layout.js             # panel editor: mở/đóng, độ rộng, ẩn comment
├── core/                     # lõi dùng chung, KHÔNG phụ thuộc Vue/DOM (chạy được trong Node → có test)
│   ├── path.js               # một quy ước path
│   ├── ignore-rules.js       # file nào đáng đọc (thư mục, nhị phân, vendor, mã sinh)
│   ├── source.js             # SourceFS: has/paths/stat/read theo yêu cầu qua handle hoặc File
│   └── mask-comments.js      # maskComments (giữ vị trí) + stripComments (xoá hẳn)
├── features/
│   ├── graph/                # GraphView, GraphLegend, NodeInfo, constants
│   ├── editor/               # EditorPanel (Monaco chỉ đọc), useMonaco (tải lười), languages, panel-width
│   └── report/ReportPanel.vue
├── utils/format.js           # fmt, formatSize
└── analyzer/                 # 01-collect-files và utils.js giờ chỉ còn dùng/re-export core/; useAnalyzer giữ SourceFS
tests/                        # npm test (node:test, không cần cài thêm gì)
vite.plugins.js               # plugin Vite dùng chung cho vite.config.js và vite.config.single.js (Vue + singlefile + Monaco worker)
```

Phụ thuộc một chiều: `layout → workspace → settings`, `graph → workspace`, `graph/layout → selection`; `core/` không import gì ngoài chính nó. Store không import component.

Đọc nội dung file từ bất kỳ đâu: `workspace.readFile(path)` (ném `SourceError` với `.code` = `not-found` | `binary` | `too-large` | `read-error`), cùng `hasFile`, `statFile`, `filePaths`. Workspace không import graph; graph đăng ký "graph sink" qua `workspace.attachGraph()`.

## Checklist thử tay cho M0 (hành vi phải y như mind-map cũ)

```bash
npm install && npm run dev
```

1. Mở thư mục (Chrome/Edge: `showDirectoryPicker`; Firefox/Safari: hộp chọn thư mục) → thấy tiến độ, rồi màn hình Tổng quan.
2. Rê chuột vào node project → hiện bảng thông tin; bấm → vào chi tiết project.
3. Trong project: bấm node → làm nổi bật + bảng thông tin; bấm đúp node mờ (ghost) → nhảy sang project kia, node đó được chọn sẵn.
4. Bật/tắt "Gồm thư viện & mã sinh tự động" → phân tích lại.
5. Đổi hình dạng một loại node ở chú thích → node đổi ngay; tải lại trang vẫn giữ.
6. "Dừng sắp xếp" / "Sắp xếp lại" / "Vừa khung"; nút lọc node 3 trạng thái.
7. "Báo cáo" → hiện Markdown, "Chép Markdown" hoạt động.
8. Mở thư mục thứ hai khi đang có sơ đồ → sơ đồ cũ được xoá sạch, không lỗi.

## Checklist thử tay cho M1

Lần này **bắt buộc thử cả hai chế độ mở thư mục** (Chrome/Edge và Firefox/Safari), vì thay đổi chính là chỗ gỡ tên thư mục gốc.

```bash
npm test          # 27 test cho core/
npm run dev
```

1. Chạy lại checklist M0 (8 bước) — mọi thứ phải y như cũ. Với cùng một thư mục, **số file / node / liên kết** ở thanh trên phải bằng số đã thấy ở M0.
2. Mở một thư mục, bấm một node file, rồi trong Console (chỉ có khi `npm run dev`):
   ```js
   explorer.sel.filePath                                   // vd. 'src/App.vue' — KHÔNG có tên thư mục gốc phía trước
   await explorer.ws.readFile(explorer.sel.filePath)       // trả về nội dung file
   explorer.ws.hasFile(explorer.sel.filePath)              // true
   await explorer.ws.statFile(explorer.sel.filePath)       // { name, ext, size, … }
   explorer.ws.filePaths().length                          // số file nguồn đang giữ
   ```
3. Các lỗi có mã rõ ràng:
   ```js
   await explorer.ws.readFile('khong-co.js').catch((e) => e.code)   // 'not-found'
   await explorer.ws.readFile('anh.png').catch((e) => e.code)       // 'binary'
   await explorer.ws.readFile(explorer.sel.filePath, { maxSize: 10 }).catch((e) => e.code) // 'too-large'
   ```
4. Làm lại bước 2 ở trình duyệt còn lại (đường dẫn kiểu `webkitRelativePath`): `filePath` vẫn phải không có tên thư mục gốc và `readFile` vẫn trả về nội dung.
5. Bật/tắt "Gồm thư viện & mã sinh tự động" → phân tích lại (dùng lại danh sách file của SourceFS), rồi `readFile` vẫn hoạt động.
6. Mở thư mục thứ hai: `explorer.ws.filePaths()` chỉ còn file của thư mục mới.

## Checklist thử tay cho M2

Đây là lần đầu có thư viện mới (`monaco-editor`, `vite-plugin-monaco-editor`), nên **bắt buộc chạy lại `npm install`**. M2 chưa được build hay chạy thử ở phía tôi.

```bash
npm install
npm test          # 31 test
npm run dev
```

1. Chạy lại checklist M0 nhanh (mở thư mục → Tổng quan → vào project): sơ đồ phải y như cũ khi chưa mở editor.
2. Trong một project, **bấm một node file** → panel bên phải mở ra, hiện đường dẫn, "ngôn ngữ · kích thước" và mã có tô màu cú pháp. Lần đầu có thể thấy "Đang đọc file…" một lúc (đang tải Monaco), các lần sau gần như tức thì. Mở thử các loại: `.cs`, `.js`/`.ts`, `.vue`, `.css`, `.json`.
3. Bấm node khác → đổi file. Cuộn file A xuống giữa, sang file B, rồi quay lại A → **phải về đúng chỗ đã cuộn**.
4. **Kéo thanh chia đôi**: sơ đồ co giãn mượt, không bị méo hay trống; kéo hết cỡ vẫn còn một phần sơ đồ; tải lại trang thì độ rộng được nhớ.
5. **"Ẩn comment"**: bật thì comment biến mất, tắt thì trở lại; nút mờ đi với `.md`, `.json`, `.csproj`. File trên đĩa không đổi.
6. **Đóng/mở**: ✕ đóng panel (sơ đồ vẫn giữ node đang chọn và sơ đồ giãn ra lại đủ rộng); nút **Mã nguồn** trên thanh trên mở lại; bấm lại đúng node đang chọn cũng mở lại.
7. Bấm vào khoảng trống của sơ đồ (bỏ chọn) và đổi qua lại Tổng quan / project → panel **vẫn giữ file đang xem**.
8. Node của project khác (ghost, nét mờ) → mở được file; node endpoint / route / thư viện ngoài → **không** làm đổi panel.
9. Mở thư mục khác (hoặc đổi "Gồm thư viện…") → panel tự đóng.
10. Trình duyệt thứ hai (Firefox/Safari, kiểu `webkitdirectory`): bước 2 vẫn mở đúng file.
11. Mở Console (F12): không có lỗi đỏ, nhất là dạng *"Could not create web worker"* hay *"MonacoEnvironment"*.
12. **`npm run build` rồi `npm run build:single`**, mở file build ra và mở một file mã nguồn. Đây là chỗ rủi ro nhất (xem bên dưới).

## Rủi ro đã biết của M2

- **Build đơn file + worker của Monaco**: cả hai cấu hình giờ dùng chung `vite.plugins.js` (singlefile + `vite-plugin-monaco-editor`) giống `vite.config.js` của code-viewer. Chưa kiểm chứng bản `build:single`. Nếu panel báo lỗi worker ở bản build mà `npm run dev` vẫn chạy tốt, gửi lại thông báo lỗi.
- **Kích thước**: đang `import('monaco-editor')` đầy đủ (mọi ngôn ngữ) như code-viewer. Tải lười nên màn hình sơ đồ không nặng thêm, nhưng ở bản đơn file thì mã Monaco vẫn nằm trong file HTML. Có thể rút gọn sau bằng cách chỉ nạp ngôn ngữ cần dùng.
- **`renderer.resize()` của Sigma**: giả định Sigma 3 không tự theo dõi kích thước vùng chứa (chỉ theo cửa sổ), nên `GraphView` gọi `gs.resize()` qua ResizeObserver. Nếu sơ đồ bị méo hoặc lệch khi kéo thanh chia đôi, đây là chỗ cần xem.
