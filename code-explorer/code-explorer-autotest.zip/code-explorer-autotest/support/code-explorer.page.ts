import { expect, type Locator, type Page } from '@playwright/test';
import { pickerInit, noPickerInit } from './picker-mock';
import { readTree } from './fs-tree';

/**
 * picker: Chrome / Edge — ứng dụng gọi showDirectoryPicker (được giả lập bằng OPFS).
 * input : Firefox / Safari — ứng dụng bấm <input type="file" webkitdirectory>.
 */
export type UploadMode = 'picker' | 'input';
export const UPLOAD_MODES: UploadMode[] = ['picker', 'input'];

export class CodeExplorerPage {
  readonly page: Page;
  readonly mode: UploadMode;

  readonly uploadButton: Locator;
  readonly includeVendor: Locator;
  readonly stats: Locator;
  readonly statusText: Locator;
  readonly errorText: Locator;
  readonly emptyState: Locator;
  readonly crumbSelect: Locator;
  readonly overviewButton: Locator;
  readonly explorerToggle: Locator;
  readonly editorToggle: Locator;
  readonly reportButton: Locator;
  readonly explorer: Locator;
  readonly searchInput: Locator;
  readonly report: Locator;
  readonly editor: Locator;
  readonly canvas: Locator;

  constructor(page: Page, mode: UploadMode) {
    this.page = page;
    this.mode = mode;
    this.uploadButton = page.getByRole('button', { name: /Folder dự án/ });
    this.includeVendor = page.getByRole('checkbox', { name: /Gồm thư viện/ });
    this.stats = page.locator('.control-panel .stats');
    this.statusText = page.locator('.control-panel .status-text');
    this.errorText = page.locator('.control-panel .status-text.error');
    this.emptyState = page.locator('.empty-state');
    this.crumbSelect = page.locator('.crumbs select');
    this.overviewButton = page.getByRole('button', { name: 'Tổng quan', exact: true });
    this.explorerToggle = page.getByRole('button', { name: 'Danh sách file', exact: true });
    this.editorToggle = page.getByRole('button', { name: 'Mã nguồn', exact: true });
    this.reportButton = page.getByRole('button', { name: 'Báo cáo', exact: true });
    this.explorer = page.locator('aside.explorer');
    this.searchInput = page.getByPlaceholder(/Tìm tên file/);
    this.report = page.locator('.report');
    this.editor = page.locator('aside.editor-panel');
    this.canvas = page.locator('.graph-canvas canvas');
  }

  /** Cài giả lập TRƯỚC khi mở trang, rồi mở trang. */
  async open(): Promise<void> {
    await this.page.addInitScript(this.mode === 'picker' ? pickerInit : noPickerInit);
    await this.page.goto('/');
    await expect(this.uploadButton).toBeVisible();
  }

  /** Bấm "📁 Folder dự án" và chọn thư mục `dir` (đường dẫn thật trên đĩa). Không chờ phân tích xong. */
  async uploadFolder(dir: string): Promise<void> {
    if (this.mode === 'picker') {
      const tree = readTree(dir);
      await this.page.evaluate((t) => { (window as any).__picker.tree = t; (window as any).__picker.error = null; }, tree);
      await this.uploadButton.click();
    } else {
      const [chooser] = await Promise.all([this.page.waitForEvent('filechooser'), this.uploadButton.click()]);
      await chooser.setFiles(dir);
    }
  }

  /** Chờ phân tích + vẽ + sắp xếp bố cục xong (thanh trạng thái hết thông báo, thống kê hiện ra). */
  async waitForLoaded(timeout = 60_000): Promise<void> {
    await expect(this.stats).toBeVisible({ timeout });
    await expect(this.statusText).toHaveCount(0, { timeout });
  }

  async uploadAndWait(dir: string): Promise<void> {
    await this.uploadFolder(dir);
    await this.waitForLoaded();
  }

  /** Các chip đuôi file của Explorer: { 'Tất cả': 13, '.cs': 8, … }. */
  async extensionCounts(): Promise<Record<string, number>> {
    return this.explorer.locator('.chip').evaluateAll((chips) =>
      Object.fromEntries(
        chips.map((c) => {
          const label = Array.from(c.childNodes)
            .filter((n) => n.nodeType === 3)
            .map((n) => n.textContent ?? '')
            .join('')
            .trim();
          const n = Number((c.querySelector('b')?.textContent ?? '0').replace(/\./g, ''));
          return [label, n];
        }),
      ),
    );
  }

  /** Nhãn của các project trong ô chọn (bỏ phần "(số node)"). */
  async projectLabels(): Promise<string[]> {
    const texts = await this.crumbSelect.locator('option:not([disabled])').allTextContents();
    return texts.map((t) => t.replace(/\s*\([\d.]+\)\s*$/, '').trim());
  }

  async selectProject(label: string): Promise<void> {
    const value = await this.crumbSelect
      .locator('option', { hasText: new RegExp(`^\\s*${label.replace(/\./g, '\\.')}\\s*\\(`) })
      .getAttribute('value');
    expect(value, `không thấy project "${label}" trong ô chọn`).toBeTruthy();
    await this.crumbSelect.selectOption(value!);
  }

  async search(text: string): Promise<void> {
    await this.searchInput.fill(text);
    await expect(this.explorer.locator('.head')).toContainText('tên ·');
  }

  async openFileFromExplorer(path: string): Promise<void> {
    await this.search(path.split('/').pop()!.replace(/\.\w+$/, ''));
    await this.explorer.locator(`.item[title="${path}"]`).first().click();
  }
}
