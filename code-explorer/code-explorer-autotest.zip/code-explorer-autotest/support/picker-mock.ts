/**
 * Giả lập window.showDirectoryPicker (Chrome / Edge) — Playwright không điều khiển được hộp thoại hệ điều hành.
 *
 * Cách làm: dựng cây thư mục vào OPFS (origin private file system) rồi trả về handle THẬT của OPFS.
 * Nhờ vậy handle vẫn gửi được sang Web Worker bằng postMessage (handle giả bằng object thường thì không clone được),
 * nên luồng "chỉ giữ handle, Worker tự đọc file" của ứng dụng được chạy đúng như thật.
 *
 * Điều khiển từ test qua window.__picker:
 *   { calls: số lần ứng dụng gọi hộp thoại, tree: cây thư mục sẽ "chọn", error: 'AbortError' để giả lập bấm Huỷ }
 */
export function pickerInit(): void {
  const w = window as any;
  w.__picker = { calls: 0, tree: null, error: null };

  w.showDirectoryPicker = async () => {
    w.__picker.calls++;
    if (w.__picker.error) throw new DOMException('The user aborted a request.', w.__picker.error);
    const tree = w.__picker.tree;
    if (!tree) throw new Error('Test chưa nạp w.__picker.tree');

    const opfs = await navigator.storage.getDirectory();
    try { await opfs.removeEntry(tree.name, { recursive: true }); } catch { /* chưa có */ }
    const root = await opfs.getDirectoryHandle(tree.name, { create: true });

    const write = async (dir: any, nodes: any[]) => {
      for (const n of nodes) {
        if (n.type === 'dir') {
          await write(await dir.getDirectoryHandle(n.name, { create: true }), n.children);
          continue;
        }
        const fh = await dir.getFileHandle(n.name, { create: true });
        const ws = await fh.createWritable();
        if (n.b64 !== undefined) {
          const bin = atob(n.b64);
          const bytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          await ws.write(bytes);
        } else {
          await ws.write(new Uint8Array(n.size).fill(n.fill));
        }
        await ws.close();
      }
    };
    await write(root, tree.children);
    return root;
  };
}

/** Trình duyệt không có showDirectoryPicker (Firefox / Safari) → ứng dụng chuyển sang <input webkitdirectory>. */
export function noPickerInit(): void {
  Object.defineProperty(window, 'showDirectoryPicker', { value: undefined, configurable: true, writable: true });
}
