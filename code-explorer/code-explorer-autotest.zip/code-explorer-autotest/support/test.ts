import { test as base, expect } from '@playwright/test';
import path from 'node:path';
import { CodeExplorerPage, type UploadMode } from './code-explorer.page';

export const FIXTURES = {
  aspNetSample: path.resolve(__dirname, '../fixtures/AspNetSample'),
  aspNetSolution: path.resolve(__dirname, '../fixtures/AspNetSolution'),
};

/** Kết quả mong đợi của fixtures/AspNetSample (khớp quy tắc bỏ qua trong README / core/ignore-rules.js). */
export const SAMPLE = {
  rootName: 'AspNetSample',
  /** Mặc định: bỏ bin/ obj/ *.png, wwwroot/lib/jquery.js, *.Designer.cs, AssemblyInfo.cs */
  defaultCounts: { 'Tất cả': 13, '.cs': 8, '.csproj': 1, '.json': 1, '.cshtml': 1, '.css': 1, '.js': 1 },
  skippedText: 'bỏ qua 3 file thư viện / sinh tự động',
  /** Bật "Gồm thư viện & mã sinh tự động": thêm jquery.js, Legacy.Designer.cs, AssemblyInfo.cs */
  vendorCounts: { 'Tất cả': 16, '.cs': 10, '.csproj': 1, '.json': 1, '.cshtml': 1, '.css': 1, '.js': 2 },
};

type Fixtures = { mode: UploadMode; app: CodeExplorerPage; pageErrors: string[] };

export const test = base.extend<Fixtures>({
  mode: ['picker', { option: true }],

  pageErrors: async ({ page }, use) => {
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(e.message));
    await use(errors);
  },

  app: async ({ page, mode, pageErrors }, use) => {
    const app = new CodeExplorerPage(page, mode);
    await app.open();
    await use(app);
    expect(pageErrors, 'Trang không được phát sinh lỗi JavaScript chưa bắt').toEqual([]);
  },
});

export { expect };
