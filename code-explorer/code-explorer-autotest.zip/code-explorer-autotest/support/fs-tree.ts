import fs from 'node:fs';
import path from 'node:path';

export type TreeNode =
  | { type: 'dir'; name: string; children: TreeNode[] }
  | { type: 'file'; name: string; b64?: string; size?: number; fill?: number };

const BIG_FILE = 1024 * 1024;

/** Đọc một thư mục thật trên đĩa thành cây JSON (để dựng lại trong OPFS của trình duyệt). */
export function readTree(dir: string): Extract<TreeNode, { type: 'dir' }> {
  return { type: 'dir', name: path.basename(dir), children: readChildren(dir) };
}

function readChildren(dir: string): TreeNode[] {
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((e): TreeNode => {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) return { type: 'dir', name: e.name, children: readChildren(full) };
      const buf = fs.readFileSync(full);
      if (buf.length > BIG_FILE) {
        // File lớn: chỉ hỗ trợ nội dung đồng nhất (file do test tự sinh) để khỏi truyền base64 vài MB
        if (!buf.every((b) => b === buf[0])) throw new Error(`File lớn không đồng nhất: ${full}`);
        return { type: 'file', name: e.name, size: buf.length, fill: buf[0] };
      }
      return { type: 'file', name: e.name, b64: buf.toString('base64') };
    });
}

/** Tạo thư mục tạm từ map { 'đường/dẫn.cs': nội dung | Buffer } và trả về đường dẫn thư mục gốc. */
export function createFolder(parent: string, name: string, files: Record<string, string | Buffer>): string {
  const root = path.join(parent, name);
  fs.rmSync(root, { recursive: true, force: true });
  fs.mkdirSync(root, { recursive: true });
  for (const [rel, content] of Object.entries(files)) {
    const full = path.join(root, rel);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content);
  }
  return root;
}
