import { defineConfig, devices } from '@playwright/test';
import path from 'node:path';

/**
 * Biến môi trường:
 *   BASE_URL     URL ứng dụng đang chạy sẵn (vd. http://localhost:4173). Có biến này thì KHÔNG tự bật server.
 *   APP_DIR      Thư mục source Code Explorer (mặc định: thư mục cha — khi đặt autotest/ trong repo).
 *   APP_COMMAND  Lệnh bật server (mặc định: npm run dev -- --port 5173 --strictPort).
 *   APP_PORT     Cổng (mặc định 5173).
 */
const PORT = Number(process.env.APP_PORT ?? 5173);
const BASE_URL = process.env.BASE_URL ?? `http://localhost:${PORT}`;
const APP_DIR = process.env.APP_DIR ?? path.resolve(__dirname, '..');
const APP_COMMAND = process.env.APP_COMMAND ?? `npm run dev -- --port ${PORT} --strictPort`;

export default defineConfig({
  testDir: './tests',
  timeout: 90_000,
  expect: { timeout: 15_000 },
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    baseURL: BASE_URL,
    viewport: { width: 1440, height: 900 },
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    locale: 'vi-VN',
    launchOptions: {
      // Sigma.js cần WebGL: ép dùng SwiftShader để chạy được cả khi headless / không có GPU
      args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
    },
  },
  projects: [
    // Chrome / Edge: có showDirectoryPicker. Firefox / Safari (webkitdirectory) được phủ bằng chế độ "input" ngay trong Chromium.
    { name: 'chromium', use: { ...devices['Desktop Chrome'], viewport: { width: 1440, height: 900 } } },
  ],
  webServer: process.env.BASE_URL
    ? undefined
    : {
        command: APP_COMMAND,
        cwd: APP_DIR,
        url: BASE_URL,
        reuseExistingServer: !process.env.CI,
        timeout: 120_000,
      },
});
