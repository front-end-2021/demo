import { test, expect, FIXTURES, SAMPLE } from '../support/test';
import { UPLOAD_MODES } from '../support/code-explorer.page';
import { createFolder } from '../support/fs-tree';

for (const mode of UPLOAD_MODES) {
  test.describe(`Ô "Gồm thư viện & mã sinh tự động" sau khi tải project [${mode}]`, () => {
    test.use({ mode });

    test(`TC-20 Bật rồi tắt: phân tích lại thư mục đang mở, không cần chọn lại @${mode}`, async ({ app, page }) => {
      await app.uploadAndWait(FIXTURES.aspNetSample);
      await expect.poll(() => app.extensionCounts()).toEqual(SAMPLE.defaultCounts);

      // Bật: thêm jquery.js, Legacy.Designer.cs, AssemblyInfo.cs
      await app.includeVendor.check();
      await expect.poll(() => app.extensionCounts(), { timeout: 60_000 }).toEqual(SAMPLE.vendorCounts);
      await app.waitForLoaded();
      await expect(app.stats).not.toContainText('bỏ qua');
      await expect(app.errorText).toHaveCount(0);

      // Tắt: về đúng như ban đầu
      await app.includeVendor.uncheck();
      await expect.poll(() => app.extensionCounts(), { timeout: 60_000 }).toEqual(SAMPLE.defaultCounts);
      await app.waitForLoaded();
      await expect(app.stats).toContainText(SAMPLE.skippedText);

      // Hộp thoại chọn thư mục KHÔNG bị gọi lại khi phân tích lại
      if (mode === 'picker') expect(await page.evaluate(() => (window as any).__picker.calls)).toBe(1);
    });

    test(`TC-21 Ô tuỳ chọn được chọn trước khi tải thì áp dụng ngay @${mode}`, async ({ app }) => {
      await app.includeVendor.check();
      await app.uploadAndWait(FIXTURES.aspNetSample);
      await expect.poll(() => app.extensionCounts()).toEqual(SAMPLE.vendorCounts);
    });
  });
}

// .gitignore là file ẩn: Chrome có thể không đưa file ẩn vào <input webkitdirectory>, nên chỉ kiểm ở chế độ picker.
test.describe('Quy tắc .gitignore ở thư mục gốc [picker]', () => {
  test.use({ mode: 'picker' });

  test('TC-22 File khớp .gitignore bị bỏ qua, bật "Gồm thư viện…" thì lấy lại @picker', async ({ app }, testInfo) => {
    const dir = createFolder(testInfo.outputPath('folders'), 'GitIgnoreDemo', {
      '.gitignore': 'Generated/\n*.log\n',
      'App.csproj': '<Project Sdk="Microsoft.NET.Sdk.Web"></Project>\n',
      'Program.cs': 'var builder = WebApplication.CreateBuilder(args);\nvar app = builder.Build();\napp.Run();\n',
      'Generated/Auto.cs': 'namespace Demo; public class Auto { }\n',
      'debug.log': 'log\n',
    });
    await app.uploadAndWait(dir);
    await expect.poll(() => app.extensionCounts()).toEqual({ 'Tất cả': 3, '.csproj': 1, '.cs': 1, '(không đuôi)': 1 });

    await app.includeVendor.check();
    await expect
      .poll(() => app.extensionCounts(), { timeout: 60_000 })
      .toEqual({ 'Tất cả': 5, '.cs': 2, '.csproj': 1, '.log': 1, '(không đuôi)': 1 });
  });
});
