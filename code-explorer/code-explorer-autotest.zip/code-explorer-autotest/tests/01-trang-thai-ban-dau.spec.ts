import { test, expect, FIXTURES } from '../support/test';

test.describe('Nút "📁 Folder dự án" — trạng thái ban đầu và cách gọi hộp thoại', () => {
  test('TC-01 Trang mở ra ở trạng thái chưa có dự án @picker', async ({ app, page }) => {
    await expect(page).toHaveTitle('Code Explorer');
    await expect(page.getByRole('heading', { name: 'Code Explorer' })).toBeVisible();
    await expect(app.uploadButton).toBeEnabled();
    await expect(app.includeVendor).not.toBeChecked();
    await expect(app.emptyState).toContainText('Chọn thư mục dự án');

    // Chưa có dữ liệu: không có thanh điều hướng, Explorer, thống kê
    await expect(app.overviewButton).toHaveCount(0);
    await expect(app.reportButton).toHaveCount(0);
    await expect(app.explorer).toHaveCount(0);
    await expect(app.stats).toHaveCount(0);
  });

  test('TC-02 Môi trường kiểm thử hỗ trợ WebGL (Sigma.js cần) @picker', async ({ page, app }) => {
    const hasWebGL = await page.evaluate(() => {
      const c = document.createElement('canvas');
      return !!(c.getContext('webgl2') || c.getContext('webgl'));
    });
    expect(hasWebGL, 'Chromium không tạo được WebGL — kiểm tra launchOptions.args trong playwright.config.ts').toBe(true);
    await expect(app.uploadButton).toBeEnabled();
  });

  test.describe('Chrome / Edge', () => {
    test.use({ mode: 'picker' });

    test('TC-03 Bấm nút gọi showDirectoryPicker đúng một lần @picker', async ({ app, page }) => {
      await app.uploadAndWait(FIXTURES.aspNetSample);
      const calls = await page.evaluate(() => (window as any).__picker.calls);
      expect(calls).toBe(1);
    });

    test('TC-04 Bấm Huỷ trong hộp thoại: giữ nguyên trạng thái, không báo lỗi @picker', async ({ app, page }) => {
      await page.evaluate(() => { (window as any).__picker.error = 'AbortError'; });
      await app.uploadButton.click();

      await expect.poll(() => page.evaluate(() => (window as any).__picker.calls)).toBe(1);
      await expect(app.uploadButton).toBeEnabled();
      await expect(app.errorText).toHaveCount(0);
      await expect(app.stats).toHaveCount(0);
      await expect(app.emptyState).toContainText('Chọn thư mục dự án');
    });

    test('TC-05 Sau khi Huỷ vẫn chọn lại được thư mục @picker', async ({ app, page }) => {
      await page.evaluate(() => { (window as any).__picker.error = 'AbortError'; });
      await app.uploadButton.click();
      await expect.poll(() => page.evaluate(() => (window as any).__picker.calls)).toBe(1);

      await app.uploadAndWait(FIXTURES.aspNetSample);
      await expect(app.stats).toContainText(/\d+\s+file/);
    });
  });

  test.describe('Firefox / Safari (không có showDirectoryPicker)', () => {
    test.use({ mode: 'input' });

    test('TC-06 Bấm nút mở hộp chọn thư mục của <input webkitdirectory> @input', async ({ app, page }) => {
      const input = page.locator('input[type="file"][webkitdirectory]');
      await expect(input).toHaveCount(1);
      await expect(input).toBeHidden();

      const [chooser] = await Promise.all([page.waitForEvent('filechooser'), app.uploadButton.click()]);
      expect(chooser.isMultiple()).toBe(true);
      expect(await page.evaluate(() => (window as any).showDirectoryPicker)).toBeUndefined();
    });
  });
});
