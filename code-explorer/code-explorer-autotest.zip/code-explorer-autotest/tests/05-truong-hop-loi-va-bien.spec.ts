import { test, expect, FIXTURES, SAMPLE } from '../support/test';
import { UPLOAD_MODES } from '../support/code-explorer.page';
import { createFolder } from '../support/fs-tree';

for (const mode of UPLOAD_MODES) {
  test.describe(`Trường hợp lỗi và biên khi tải thư mục [${mode}]`, () => {
    test.use({ mode });

    test(`TC-40 Thư mục không có mã nguồn được hỗ trợ → báo lỗi @${mode}`, async ({ app }, testInfo) => {
      const dir = createFolder(testInfo.outputPath('folders'), 'OnlyDocs', {
        'notes.txt': 'ghi chú',
        'docs/readme.md': '# tài liệu',
      });
      await app.uploadFolder(dir);

      await expect(app.errorText).toHaveText('Không tìm thấy file mã nguồn được hỗ trợ trong thư mục này.');
      await expect(app.uploadButton).toBeEnabled();
      await expect(app.overviewButton).toHaveCount(0);
      await expect(app.explorer).toHaveCount(0);
    });

    test(`TC-41 File lớn hơn 3 MB bị bỏ qua và được báo trên thanh thống kê @${mode}`, async ({ app }, testInfo) => {
      const dir = createFolder(testInfo.outputPath('folders'), 'BigFile', {
        'Big.csproj': '<Project Sdk="Microsoft.NET.Sdk.Web"></Project>\n',
        'Program.cs': 'var app = WebApplication.CreateBuilder(args).Build();\napp.Run();\n',
        'Huge.cs': Buffer.alloc(3 * 1024 * 1024 + 512, 'a'),
      });
      await app.uploadAndWait(dir);
      await expect(app.stats).toContainText('1 file > 3 MB');
      await expect(app.errorText).toHaveCount(0);
    });

    test(`TC-42 Chọn thư mục thứ hai thay thế hoàn toàn thư mục thứ nhất @${mode}`, async ({ app }) => {
      await app.uploadAndWait(FIXTURES.aspNetSample);
      await expect.poll(() => app.extensionCounts()).toEqual(SAMPLE.defaultCounts);
      await expect(app.stats).toContainText(/\b1\s+project/);

      await app.uploadAndWait(FIXTURES.aspNetSolution);
      await expect(app.stats).toContainText(/\b2\s+project/);
      await expect(app.crumbSelect.locator('option[disabled]')).toHaveText('AspNetSolution');
      expect(await app.projectLabels()).toEqual(['Shop.Core', 'Shop.Web']);

      const counts = await app.extensionCounts();
      expect(counts['Tất cả']).toBe(8);
      expect(counts['.cshtml'], 'file của thư mục cũ không được còn sót').toBeUndefined();
      await expect(app.errorText).toHaveCount(0);
    });

    test(`TC-43 Sau lần tải lỗi vẫn tải được project hợp lệ @${mode}`, async ({ app }, testInfo) => {
      const bad = createFolder(testInfo.outputPath('folders'), 'OnlyDocs2', { 'a.txt': 'x' });
      await app.uploadFolder(bad);
      await expect(app.errorText).toBeVisible();

      await app.uploadAndWait(FIXTURES.aspNetSample);
      await expect(app.errorText).toHaveCount(0);
      await expect(app.stats).toContainText(/\b1\s+project/);
    });
  });
}

test.describe('Thư mục rỗng [picker]', () => {
  test.use({ mode: 'picker' });

  test('TC-44 Thư mục không có file nào → báo lỗi @picker', async ({ app }, testInfo) => {
    const dir = createFolder(testInfo.outputPath('folders'), 'Empty', {});
    await app.uploadFolder(dir);
    await expect(app.errorText).toHaveText('Không tìm thấy file nào trong thư mục này.');
    await expect(app.uploadButton).toBeEnabled();
  });

  test('TC-45 Thư mục chỉ có bin/ obj/ (bị bỏ qua ngay khi duyệt) → báo lỗi @picker', async ({ app }, testInfo) => {
    const dir = createFolder(testInfo.outputPath('folders'), 'OnlyBuildOutput', {
      'bin/Debug/Program.cs': 'class A {}',
      'obj/Generated.cs': 'class B {}',
    });
    await app.uploadFolder(dir);
    await expect(app.errorText).toHaveText('Không tìm thấy file nào trong thư mục này.');
  });
});
