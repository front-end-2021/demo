import { test, expect, FIXTURES } from '../support/test';
import { UPLOAD_MODES } from '../support/code-explorer.page';

for (const mode of UPLOAD_MODES) {
  test.describe(`Tải solution ASP.NET nhiều project [${mode}]`, () => {
    test.use({ mode });

    test.beforeEach(async ({ app }) => {
      await app.uploadAndWait(FIXTURES.aspNetSolution);
    });

    test(`TC-30 Mở màn hình Tổng quan với 2 project @${mode}`, async ({ app }) => {
      await expect(app.errorText).toHaveCount(0);
      await expect(app.stats).toContainText(/\b2\s+project/);
      await expect(app.overviewButton).toHaveClass(/active/);
      expect(await app.projectLabels()).toEqual(['Shop.Core', 'Shop.Web']);
      await expect(app.crumbSelect.locator('option[disabled]')).toHaveText('AspNetSolution');
      await expect(app.canvas.first()).toBeVisible();
    });

    test(`TC-31 Chuyển giữa Tổng quan và từng project @${mode}`, async ({ app }) => {
      await app.selectProject('Shop.Web');
      await expect(app.crumbSelect).toHaveValue('Shop.Web/');
      await expect(app.overviewButton).not.toHaveClass(/active/);
      await expect(app.statusText).toHaveCount(0);

      await app.selectProject('Shop.Core');
      await expect(app.crumbSelect).toHaveValue('Shop.Core/');
      await expect(app.statusText).toHaveCount(0);

      await app.overviewButton.click();
      await expect(app.overviewButton).toHaveClass(/active/);
      await expect(app.crumbSelect).toHaveValue('');
      await expect(app.errorText).toHaveCount(0);
    });

    test(`TC-32 Explorer có file của cả hai project @${mode}`, async ({ app }) => {
      const counts = await app.extensionCounts();
      expect(counts['.cs']).toBe(5);       // Program, OrdersController, Order, IOrderService, OrderService
      expect(counts['.csproj']).toBe(2);
      expect(counts['.sln']).toBe(1);
      expect(counts['Tất cả']).toBe(8);
    });

    test(`TC-33 Báo cáo nhận diện ASP.NET cho solution @${mode}`, async ({ app }) => {
      await app.reportButton.click();
      await expect(app.report).toContainText('aspnet');
      await expect(app.report).toContainText('Shop.Web/Program.cs');
    });
  });
}
