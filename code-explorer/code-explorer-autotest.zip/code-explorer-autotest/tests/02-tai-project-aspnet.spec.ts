import { test, expect, FIXTURES, SAMPLE } from '../support/test';
import { UPLOAD_MODES } from '../support/code-explorer.page';

for (const mode of UPLOAD_MODES) {
  test.describe(`Tải project ASP.NET bằng "📁 Folder dự án" [${mode}]`, () => {
    test.use({ mode });

    test.beforeEach(async ({ app }) => {
      await app.uploadAndWait(FIXTURES.aspNetSample);
    });

    test(`TC-10 Phân tích thành công, mở thẳng chi tiết project duy nhất @${mode}`, async ({ app }) => {
      await expect(app.errorText).toHaveCount(0);
      await expect(app.emptyState).toHaveCount(0);
      await expect(app.uploadButton).toBeEnabled();

      // Thống kê: "N file · N node · N liên kết · 1 project"
      await expect(app.stats).toContainText(/\d+\s+file\s+·\s+\d+\s+node\s+·\s+\d+\s+liên kết\s+·\s+1\s+project/);

      // Chỉ có 1 project → app mở thẳng vào chi tiết project đó (không dừng ở Tổng quan)
      expect(await app.projectLabels()).toEqual([SAMPLE.rootName]);
      await expect(app.crumbSelect).toHaveValue('/');
      await expect(app.overviewButton).not.toHaveClass(/active/);
      await expect(app.crumbSelect.locator('option[disabled]')).toHaveText(SAMPLE.rootName);
    });

    test(`TC-11 Hiện các nút điều hướng và các tab sau khi tải @${mode}`, async ({ app, page }) => {
      await expect(app.overviewButton).toBeVisible();
      await expect(app.explorerToggle).toBeVisible();
      await expect(app.editorToggle).toBeVisible();
      await expect(app.reportButton).toBeEnabled();
      for (const tab of ['Sơ đồ file', 'Sơ đồ class', 'Lịch sử lọc']) {
        await expect(page.getByRole('tab', { name: new RegExp(tab) })).toBeVisible();
      }
    });

    test(`TC-12 Sơ đồ được vẽ bằng WebGL (canvas hiển thị, không lỗi) @${mode}`, async ({ app }) => {
      await expect(app.canvas.first()).toBeVisible();
      expect(await app.canvas.count()).toBeGreaterThan(0);
      await expect(app.errorText).toHaveCount(0);
    });

    test(`TC-13 Explorer liệt kê đúng file, bỏ bin/ obj/ ảnh, thư viện và mã sinh tự động @${mode}`, async ({ app }) => {
      await expect(app.explorer).toBeVisible();
      // Khớp chính xác: không có .dll .png (nhị phân), không có file trong obj/ bin/ …
      await expect.poll(() => app.extensionCounts()).toEqual(SAMPLE.defaultCounts);
      await expect(app.stats).toContainText(SAMPLE.skippedText);
    });

    test(`TC-14 Báo cáo nhận diện ASP.NET @${mode}`, async ({ app }) => {
      await app.reportButton.click();
      await expect(app.report).toBeVisible();
      await expect(app.report).toContainText('Báo cáo cấu trúc dự án');
      await expect(app.report).toContainText('aspnet');
      await expect(app.report).toContainText('dotnet');
      await expect(app.report).toContainText('Program.cs'); // điểm khởi đầu
      await expect(app.report.getByRole('button', { name: 'Chép Markdown' })).toBeVisible();

      await app.report.getByRole('button', { name: '✕' }).click();
      await expect(app.report).toHaveCount(0);
    });

    test(`TC-15 Tìm tên file và symbol (class controller) @${mode}`, async ({ app }) => {
      await app.search('ProductsController');
      await expect(app.explorer.locator('.sec', { hasText: /^Tên file/ })).toBeVisible();
      await expect(app.explorer.locator('.sec', { hasText: /^Symbol/ })).toBeVisible();
      await expect(app.explorer.locator('.item[title="Controllers/ProductsController.cs"]').first()).toBeVisible();
    });

    test(`TC-16 Tìm trong nội dung file (Worker đọc lại file đã tải) @${mode}`, async ({ app }) => {
      await app.search('AddScoped');
      await expect(app.explorer.locator('.sec', { hasText: /^Nội dung/ })).toBeVisible();
      await expect(app.explorer.locator('.item[title^="Program.cs"]').first()).toBeVisible();
    });

    test(`TC-17 Bấm một file trong Explorer mở mã nguồn @${mode}`, async ({ app }) => {
      await app.openFileFromExplorer('Program.cs');
      await expect(app.editor).toBeVisible();
      await expect(app.editor.locator('.crumb b')).toHaveText('Program.cs');
      await expect(app.editor.locator('.monaco-editor .view-lines')).toContainText('WebApplication', { timeout: 30_000 });
    });
  });
}
