# Autotest Playwright — "📁 Folder dự án" (tải project ASP.NET)

Bộ test E2E cho chức năng bấm **📁 Folder dự án** của Code Explorer để tải một thư mục project ASP.NET lên phân tích.

## Cài đặt & chạy

Đặt thư mục này vào repo Code Explorer (ví dụ `code-explorer/autotest/`), rồi:

```bash
cd autotest
npm install
npx playwright install chromium
npm test                 # tự bật `npm run dev` ở thư mục cha rồi chạy
npm run test:headed      # xem trình duyệt chạy
npm run test:ui          # giao diện debug của Playwright
npm run report           # mở báo cáo HTML
```

| Biến môi trường | Ý nghĩa |
| --- | --- |
| `BASE_URL` | Dùng app đã chạy sẵn (vd. `http://localhost:4173` của `npm run preview`) — không tự bật server |
| `APP_DIR` | Thư mục source app (mặc định: thư mục cha) |
| `APP_COMMAND` | Lệnh bật server (mặc định `npm run dev -- --port 5173 --strictPort`) |

## Cách xử lý hộp thoại chọn thư mục

Playwright không điều khiển được hộp thoại của hệ điều hành, nên có hai chế độ, **mỗi test chạy cả hai** (gắn tag `@picker` / `@input`):

- **`picker` (Chrome / Edge):** app gọi `showDirectoryPicker`. Test thay hàm này bằng bản giả dựng cây thư mục vào **OPFS** và trả về handle thật → handle vẫn gửi được sang Web Worker như khi chạy thật (`support/picker-mock.ts`).
- **`input` (Firefox / Safari):** xoá `showDirectoryPicker`, app tự bấm `<input webkitdirectory>`; test bắt `filechooser` và `setFiles(thư mục)`.

## Fixture

- `fixtures/AspNetSample` — Web API + MVC: controller, DI, DbContext, minimal API, kèm `bin/`, `obj/`, ảnh, `wwwroot/lib/jquery.js`, `*.Designer.cs`, `AssemblyInfo.cs` để kiểm tra bộ lọc.
- `fixtures/AspNetSolution` — solution 2 project (`Shop.Web` dùng `Shop.Core`) để kiểm tra màn hình Tổng quan.
- Thư mục lỗi/biên (rỗng, chỉ tài liệu, file > 3 MB, `.gitignore`) được test tự sinh trong thư mục tạm.

## Danh sách test case

| Nhóm | Mã | Kiểm tra |
| --- | --- | --- |
| 01 Trạng thái ban đầu | TC-01…06 | Màn hình trống; WebGL; nút gọi `showDirectoryPicker` 1 lần; Huỷ hộp thoại không lỗi; chọn lại sau khi Huỷ; chế độ `<input webkitdirectory>` |
| 02 Tải project ASP.NET | TC-10…17 | Thống kê, mở thẳng project duy nhất, nút/tab xuất hiện, canvas WebGL, **số file theo đuôi chính xác** (bỏ bin/obj/ảnh/thư viện/mã sinh), báo cáo có `aspnet`/`dotnet`/`Program.cs`, tìm tên/symbol/nội dung, mở file trong Monaco |
| 03 Gồm thư viện | TC-20…22 | Bật/tắt phân tích lại không gọi lại hộp thoại; bật trước khi tải; quy tắc `.gitignore` |
| 04 Solution | TC-30…33 | Tổng quan 2 project, chuyển project, file của cả hai project, báo cáo |
| 05 Lỗi & biên | TC-40…45 | Không có mã nguồn hỗ trợ; file > 3 MB; thư mục thứ hai thay thế thư mục đầu; hồi phục sau lỗi; thư mục rỗng; chỉ có bin/obj |

## Ghi chú

- App chưa có `data-testid`, nên selector dựa trên role/text/class hiện có (`.stats`, `.status-text`, `.crumbs select`, `aside.explorer`, `.chip`, `.report`…). Nếu đổi giao diện, chỉnh tập trung ở `support/code-explorer.page.ts`.
- `.gitignore` là file ẩn; Chrome có thể không đưa file ẩn vào `<input webkitdirectory>`, nên TC-22 chỉ chạy ở chế độ `picker`.
- Số file mong đợi (`SAMPLE` trong `support/test.ts`) bám theo quy tắc ở `src/core/ignore-rules.js`. Nếu bạn đổi quy tắc đó hoặc thêm file vào fixture, cập nhật lại các con số này.
- Thêm Firefox/WebKit: thêm project trong `playwright.config.ts` và chỉ chạy các test `@input`.
