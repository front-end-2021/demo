using Shop.Core.Models;

namespace Shop.Core.Services;

public interface IOrderService
{
    IEnumerable<Order> List();
}
