using Shop.Core.Models;

namespace Shop.Core.Services;

public class OrderService : IOrderService
{
    public IEnumerable<Order> List() => new List<Order>();
}
