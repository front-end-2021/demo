using Microsoft.AspNetCore.Mvc;
using Shop.Core.Models;
using Shop.Core.Services;

namespace Shop.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly IOrderService _orders;

    public OrdersController(IOrderService orders)
    {
        _orders = orders;
    }

    [HttpGet]
    public IEnumerable<Order> List() => _orders.List();
}
