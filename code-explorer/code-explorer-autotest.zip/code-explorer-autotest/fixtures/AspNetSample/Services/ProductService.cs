using AspNetSample.Data;
using AspNetSample.Models;

namespace AspNetSample.Services;

public class ProductService : IProductService
{
    private readonly AppDbContext _db;

    public ProductService(AppDbContext db)
    {
        _db = db;
    }

    public IEnumerable<Product> GetAll() => _db.Products.ToList();

    public Product? GetById(int id) => _db.Products.Find(id);

    public Product Add(Product product)
    {
        _db.Products.Add(product);
        _db.SaveChanges();
        return product;
    }
}
