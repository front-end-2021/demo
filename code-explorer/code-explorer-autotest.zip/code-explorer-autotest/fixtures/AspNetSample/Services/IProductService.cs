using AspNetSample.Models;

namespace AspNetSample.Services;

public interface IProductService
{
    IEnumerable<Product> GetAll();
    Product? GetById(int id);
    Product Add(Product product);
}
