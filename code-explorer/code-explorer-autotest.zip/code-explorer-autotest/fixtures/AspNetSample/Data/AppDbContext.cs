using AspNetSample.Models;
using Microsoft.EntityFrameworkCore;

namespace AspNetSample.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Product> Products => Set<Product>();
}
