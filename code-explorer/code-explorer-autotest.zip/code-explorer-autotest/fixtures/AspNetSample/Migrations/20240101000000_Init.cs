namespace AspNetSample.Migrations;

public partial class Init
{
    protected void Up()
    {
    }
}
