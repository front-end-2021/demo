namespace AspNetSample.Models
{
    // Mã sinh tự động: mặc định bị bỏ qua
    public partial class Legacy
    {
        public int Value { get; set; }
    }
}
