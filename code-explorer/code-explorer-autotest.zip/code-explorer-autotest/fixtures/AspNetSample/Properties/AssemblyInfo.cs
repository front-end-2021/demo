using System.Reflection;

[assembly: AssemblyTitle("AspNetSample")]
