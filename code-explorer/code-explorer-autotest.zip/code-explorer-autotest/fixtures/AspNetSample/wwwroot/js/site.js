async function loadProducts() {
  const res = await fetch('/api/products');
  const items = await res.json();
  document.getElementById('products').textContent = items.map((p) => p.name).join(', ');
}

loadProducts();
