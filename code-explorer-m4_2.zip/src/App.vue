<template>
  <div class="app-container">
    <TopBar />
    <div ref="splitEl" class="main-split">
      <template v-if="showExplorer">
        <ExplorerPanel :style="{ width: layout.explorerWidth + 'px' }" />
        <SplitHandle @drag="onDragExplorer" />
      </template>
      <GraphView />
      <template v-if="layout.editorOpen">
        <SplitHandle @drag="onDragEditor" />
        <EditorPanel :style="{ width: layout.editorWidth + 'px' }" />
      </template>
    </div>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref } from 'vue'
import TopBar from './components/TopBar.vue'
import SplitHandle from './components/SplitHandle.vue'
import GraphView from './features/graph/GraphView.vue'
import EditorPanel from './features/editor/EditorPanel.vue'
import ExplorerPanel from './features/explorer/ExplorerPanel.vue'
import { useLayoutStore } from './stores/layout'
import { useWorkspaceStore } from './stores/workspace'
import { useSearchStore } from './stores/search'

const layout = useLayoutStore()
const workspace = useWorkspaceStore()
const search = useSearchStore() // tạo sớm để kết quả tìm kiếm luôn được chuyển sang sơ đồ

const splitEl = ref(null)
const showExplorer = computed(() => layout.explorerOpen && !!workspace.fileIndex)

// Explorer ở bên trái: độ rộng = vị trí con trỏ − mép trái vùng chứa. Editor ở bên phải: ngược lại.
function onDragExplorer(clientX) {
  const rect = splitEl.value.getBoundingClientRect()
  layout.setExplorerWidth(clientX - rect.left, rect.width)
}

function onDragEditor(clientX) {
  const rect = splitEl.value.getBoundingClientRect()
  layout.setEditorWidth(rect.right - clientX, rect.width)
}

// Ctrl/Cmd + K: mở Explorer và đưa con trỏ vào ô tìm (bắt ở pha capture để cả khi đang ở trong editor cũng dùng được)
async function onKeydown(e) {
  if (!(e.ctrlKey || e.metaKey) || e.shiftKey || e.altKey || e.key.toLowerCase() !== 'k') return
  e.preventDefault()
  if (!workspace.fileIndex) return
  layout.explorerOpen = true
  await nextTick() // chờ panel dựng xong rồi mới yêu cầu focus
  search.focusInput()
}

onMounted(() => window.addEventListener('keydown', onKeydown, true))
onBeforeUnmount(() => window.removeEventListener('keydown', onKeydown, true))
</script>

<style scoped>
.app-container {
  display: flex;
  flex-direction: column;
  width: 100vw;
  height: 100vh;
  background-color: #f8f9fa;
}

.main-split {
  flex: 1;
  display: flex;
  min-height: 0;
}
</style>
