# Code Explorer — lộ trình gộp 3 project

Gộp **mind-map** (nền), **code-viewer** và **class-diagram** thành một ứng dụng khám phá mã nguồn:

```
Tổng quan (project)  →  Project (file)  →  File (class + thành viên)
     mind-map              mind-map            class-diagram
                     Editor / tìm kiếm: code-viewer
```

## Trạng thái

| Mốc | Nội dung | Trạng thái |
| --- | --- | --- |
| **M0** | Tách `App.vue` của mind-map, dựng store | **Xong**, đã thử tay |
| **M1** | Lõi chung: `core/path.js`, `ignore-rules.js`, `source.js`, `mask-comments.js` | **Xong**, đã thử tay |
| **M2** | Editor chỉ đọc: bấm node → mở file trong panel bên phải (Monaco tải lười), kéo thanh chia đôi, "Ẩn comment" | **Xong**, đã thử tay (build đã được sửa — xem "Ghi chú build") |
| **M3** | Explorer (danh sách file, chip đuôi file) + tìm kiếm tên / symbol / nội dung (Worker), làm nổi bật node trên sơ đồ, nhảy dòng và tô sáng từ khoá trong editor | **Xong**, đã thử tay |
| **M4** | Dải quan hệ trong editor: **Định nghĩa · Dùng · Được dùng bởi**, nhảy tới dòng định nghĩa / dòng đang dùng, kể cả sang project khác và qua lời gọi API | **Xong phần mã** — 62 test qua; **chờ thử tay** (checklist M4) |
| M5 | Sơ đồ class **C#** cho các file đang chọn | Chưa |
| M5b | Sơ đồ class **Java** và **Python** cho các file đang chọn | Chưa |

**Đã bỏ khỏi phạm vi:** sửa và lưu file ra đĩa, phân tích lại từng file. Ứng dụng chỉ đọc.

## Bản đồ: mã của hai project kia sẽ vào đâu

| Nguồn | Đích | Thay đổi cần làm |
| --- | --- | --- |
| code-viewer `components/CodeEditor.vue` | `features/editor/EditorPanel.vue` (**đã làm ở M2**, bản chỉ đọc) | Bỏ sửa/lưu/tải về (không làm), nạp Monaco lười, đọc qua `workspace.readFile`. Tô sáng từ khoá và nhảy dòng đã làm ở M3 |
| code-viewer `App.vue` (sidebar, chip đuôi file, tìm kiếm) | `features/explorer/` + `stores/search.js` + `core/search.js` (**đã làm ở M3**) | Tìm nội dung chuyển sang Worker (quét theo lô, huỷ được); thêm tìm theo symbol và tên file xếp hạng; danh sách ảo hoá; làm nổi bật node trên sơ đồ |
| code-viewer `utils/stripComments.js` | `core/mask-comments.js` (**đã chuyển ở M1**) | Nối vào nút "Dọn comment" của editor ở M2 |
| code-viewer `utils/file.js` (`formatSize`…) | `utils/` | Lấy khi cần ở M2 |
| class-diagram `utils/csharp.js` | `features/diagram/parsers/csharp.js` | Thêm `line`; id class = tên đầy đủ (namespace + tên); che comment giữ nguyên độ dài |
| class-diagram `utils/diagram.js` | `features/diagram/layout.js` | Giữ nguyên (hàm thuần) |
| class-diagram `ClassBox.vue`, `DiagramsView.vue`, `stores/diagram.js` | `features/diagram/` | Bỏ panel Source riêng; store đổi từ "một đoạn source" sang "tập file đang chọn"; khoá vị trí theo (file + class) |
| class-diagram `MonacoEditor.vue`, `Icon.vue` | (bỏ) | Dùng chung editor và bootstrap-icons |

## Quyết định đã chốt

- Làm trên bản sao mới, không sửa hai project gốc; JavaScript (không TypeScript).
- **Chỉ đọc**: không làm sửa/lưu file ra đĩa (đã bỏ khỏi phạm vi; trước đây là mốc M5).
- **Một bộ quy tắc lọc file** (`core/ignore-rules.js`) = bộ của analyzer. Danh sách trắng đuôi file của code-viewer **bỏ**: mọi thư mục nó loại đều đã được bộ chung loại, còn đuôi lạ (`.csproj`, `.ps1`…) giờ hiển thị như văn bản thường. Hai giới hạn kích thước tách rõ: phân tích 1 MB (`MAX_ANALYZE_SIZE`), xem trong editor 5 MB (`MAX_VIEW_SIZE`).
- **Path do `core/source.js` quyết định, ngay trên luồng chính**: chuẩn hoá và gỡ tên thư mục gốc rồi mới gửi sang Worker (Worker không gỡ nữa). Nhờ vậy `node.file` ≡ khoá của `source.read(path)` ở cả Chrome/Edge lẫn Firefox/Safari.
- **Bộ che comment: đã gom về một module + một bộ test, CHƯA gộp vòng quét.** `maskComments` (giữ nguyên vị trí) và `stripComments` (xoá hẳn) có hợp đồng khác nhau. Gộp thành một bộ quét là việc của M5, làm theo kiểu "golden master" (so với hai bản cũ trên mọi file thật) vì parser class cần che chuỗi C# verbatim `@"…"` mà `maskComments` hiện chưa hiểu; lúc đó `clean()` của class-diagram cũng được thay.
- **Editor (M2)**: chỉ đọc; Monaco nạp bằng `import()` ở lần mở file đầu tiên; mỗi file một model (tối đa 24, bỏ cái lâu chưa dùng) và nhớ vị trí cuộn; bỏ chọn trên sơ đồ thì panel **giữ file đang xem**; chọn lại đúng node đang chọn thì mở lại panel (`selection.tick`); mở thư mục khác thì panel đóng. Độ rộng panel được nhớ (localStorage) và luôn chừa tối thiểu 280 px cho sơ đồ.
- **Dải quan hệ (M4)** nằm ngay dưới tên file trong editor, ba tab dạng danh sách thả xuống phủ lên editor: **Định nghĩa** (symbol của file + dòng), **Dùng** (cạnh đi ra), **Được dùng bởi** (cạnh đi vào). Dữ liệu tính trong Worker từ đồ thị ĐẦY ĐỦ (`analyzer/related.js`; giao diện chỉ giữ đồ thị của màn hình hiện tại) qua message `related` có `requestId`, không mang `job`, trả lời ngay từ bộ nhớ.
- **Nhảy đúng dòng nhờ `locs` và `labels` của cạnh**: *Dùng* → mở file được dùng ở **dòng định nghĩa** của tên đang dùng (tra `labels` trong `symbols` của file đích) và liệt kê **các dòng dùng ngay trong file hiện tại**; *Được dùng bởi* → mở file kia ở **dòng nó dùng mình**. Hai chiều gộp mọi cạnh giữa hai file thành một mục (nhiều loại quan hệ, nhiều tên).
- **Gọi API xuyên project**: cạnh `calls-api` đi tới node endpoint; dải nối tiếp tới FILE định nghĩa endpoint (cạnh `exposes` đi vào endpoint, kèm dòng định nghĩa) — và chiều ngược lại cho file controller. Mục suy đoán (khớp theo tên / URL) có dấu ≈. Thư viện ngoài chỉ hiện số lượng.
- **Giới hạn của dữ liệu**: `import` của JS/TS không mang tên symbol (nhãn chỉ có `dynamic` / `type`) nên không tra được dòng định nghĩa — mở đầu file nhưng vẫn có "dùng ở dòng…". C# (`using`), render component, kế thừa, tiêm phụ thuộc có tên nên nhảy đúng. Mỗi danh sách tối đa 200 mục, 8 tên và 6 dòng mỗi mục.
- **Tìm kiếm (M3)**: một ô, ba loại kết quả xếp thành ba mục — *Tên file* (luồng chính, tức thì, mọi từ phải khớp, tên file bắt đầu bằng từ khoá xếp trên), *Symbol* (Worker, từ mô hình phân tích; bỏ symbol kiểu `variable`), *Nội dung* (Worker, đọc file theo lô 32, kết quả về dần, gõ tiếp thì huỷ). So khớp **chuỗi con, không phân biệt hoa thường** (chưa có regex / nguyên từ). Giới hạn: 500 file nội dung, 1000 lần khớp mỗi file, 200 symbol, 500 tên file hiển thị; chỉ quét file ≤ 1 MB (giới hạn phân tích) và bỏ file nhị phân.
- **Tìm kiếm chạy trong CHÍNH Worker phân tích** (không tách worker riêng): tận dụng `entries` mà Worker đã nhận ở `load`, không phải clone handle lần nữa. Message tìm kiếm mang `searchId`, **không mang `job`** và được xử lý trước dòng `currentJob = msg.job` — vì mỗi message có `job` mới sẽ huỷ bố cục đang chạy. Nếu thấy bố cục chậm khi đang quét nội dung thì tách worker riêng.
- **Danh sách file** = chính các file analyzer đã nhận (`result.paths`), gồm cả file không có node (README, `.csproj`, `.json`…). Mỗi path kèm project của nó (`fileIndex`: `paths`, `projectIds`, `pidx`). Danh sách phẳng (như code-viewer), ảo hoá để chịu hàng chục nghìn file.
- **Mở file từ Explorer / kết quả = `graph.openFile`**: file ở project khác màn hình đang xem thì chuyển project trước, rồi chọn node và căn camera ngay khi sơ đồ dựng xong (`pendingOpen`); file không có node thì chỉ mở editor. Khi đang tìm, node có kết quả nổi lên và phần còn lại mờ đi (ở Tổng quan: các project có kết quả); chọn một node thì quy tắc "đang chọn" được ưu tiên.
- **Nhảy dòng và tô sáng**: `selection.line` / `selection.query`. Số dòng của kết quả theo bản **gốc**, nên nếu "Ẩn comment" đang bật thì tự tắt rồi mới nhảy. Chọn node thường (không qua tìm kiếm) xoá tô sáng.
- **Phím tắt**: Ctrl/Cmd + K (bắt ở pha capture nên dùng được cả khi con trỏ đang ở editor), ↑ ↓ chọn hàng, Enter mở (Enter ngay sau khi gõ = tìm ngay), Esc xoá ô tìm; chip đuôi file: Alt + bấm = chỉ chọn đuôi đó.
- **"Ẩn comment"** chỉ đổi cách hiển thị (`stripComments` với đuôi file thật — code-viewer cũ luôn truyền `'cs'` cho mọi file), không đổi file; bản đã ẩn comment dùng model riêng.
- **Theme editor đang cố định sáng** (cả ứng dụng còn ghi cứng màu sáng); chuyển sang bảng màu sáng/tối chung ở bước `styles/tokens.css`.
- **Không nạp nội dung file vào luồng chính.** Giữ handle/File, đọc theo yêu cầu (giữ khả năng chịu hàng chục nghìn file của mind-map).
- Một quy ước path duy nhất; `stores/selection.js` là nguồn sự thật cho "đang chọn gì" (sơ đồ file, editor, sơ đồ class cùng đọc/ghi).
- Sơ đồ class: **chỉ hiện class của file đang chọn**, parse **theo yêu cầu** (không nhét vào pipeline toàn dự án), giới hạn ~50-60 class mỗi sơ đồ. Không làm "thêm lớp liên quan" ở bản đầu.
- Sơ đồ class là chế độ xem riêng (DOM + SVG, tab chuyển với sơ đồ file), không vẽ trên Sigma.
- Monaco và `features/diagram` tải lười để màn hình sơ đồ file vẫn nhẹ. Cấu hình Monaco = hợp của hai project (css/html/json/typescript + csharp/java/python).
- Một bộ màu sáng/tối chung (`styles/tokens.css`) — hiện mind-map còn ghi cứng màu sáng.
- **Java và Python để sau (M5b)**. Java: `parsers/java.js` theo "hồ sơ ngôn ngữ" gần giống C#. Python: cần `parsers/python.js` riêng (không có dấu ngoặc nhọn, khối theo thụt lề, thuộc tính qua `self.x`, type hint) — không dùng chung được với bộ quét kiểu C.
- **Build (do bạn sửa ở M2.2)**: `viteSingleFile` đã tắt và giữ `vite-plugin-monaco-editor`. Bản build vì vậy **không còn là một file HTML duy nhất**: phải phục vụ qua http (`npm run preview` hoặc một web server tĩnh), mở thẳng bằng file:// sẽ không chạy. Hướng nhúng worker bằng `?worker&inline` (M2.1) cũng đã thử và build vẫn lỗi.

## Cấu trúc hiện tại (sau M3)

```
src/
├── main.js, style.css        # style.css: kiểu nút dùng chung + kiểu decoration của Monaco (.find-hit, .jump-line)
├── App.vue                   # layout: TopBar + [Explorer | Sơ đồ | Editor]; phím Ctrl K
├── components/               # TopBar, SplitHandle (thanh kéo chia đôi)
├── stores/
│   ├── workspace.js          # thư mục đang mở, kết quả phân tích, cầu nối Worker; fileIndex, search(), related()
│   ├── graph.js              # Sigma/graphology: vẽ, làm nổi bật, lọc node; openFile, setHighlight
│   ├── settings.js           # includeVendor, hình dạng node (localStorage)
│   ├── selection.js          # file/node đang chọn (+ line, query, tick)  ← khớp nối cho editor và sơ đồ class
│   ├── layout.js             # Explorer + Editor: mở/đóng, độ rộng (nhớ), ẩn comment
│   └── search.js             # ô tìm, kết quả (tên · symbol · nội dung), lọc đuôi file, làm nổi bật
├── core/                     # lõi dùng chung, KHÔNG phụ thuộc Vue/DOM (chạy được trong Node → có test)
│   ├── path.js               # một quy ước path
│   ├── ignore-rules.js       # file nào đáng đọc (thư mục, nhị phân, vendor, mã sinh)
│   ├── source.js             # SourceFS: has/paths/stat/read theo yêu cầu qua handle hoặc File
│   ├── mask-comments.js      # maskComments (giữ vị trí) + stripComments (xoá hẳn)
│   └── search.js             # rankPaths, findInText, searchContent, matchSymbols (thuần)
├── features/
│   ├── graph/                # GraphView, GraphLegend, NodeInfo, constants
│   ├── explorer/             # ExplorerPanel, VirtualList, virtual-list.js
│   ├── editor/               # EditorPanel (Monaco chỉ đọc, nhảy dòng, tô sáng), RelationsBar (Định nghĩa · Dùng · Được dùng bởi), useMonaco, languages, panel-width
│   └── report/ReportPanel.vue
├── utils/format.js           # fmt, formatSize
└── analyzer/                 # Worker phân tích + tìm kiếm + truy vấn quan hệ; related.js; 08-view-model có projectOf, searchSymbols, related
tests/                        # npm test (node:test, không cần cài thêm gì)
vite.plugins.js               # plugin Vite dùng chung cho vite.config.js và vite.config.single.js
```

Phụ thuộc một chiều: `search → graph → workspace → settings`, `layout → workspace`, `graph/layout → selection`; `core/` không import gì ngoài chính nó. Store không import component.

Đọc nội dung file từ bất kỳ đâu: `workspace.readFile(path)` (ném `SourceError` với `.code` = `not-found` | `binary` | `too-large` | `read-error`), cùng `hasFile`, `statFile`, `filePaths`. Workspace không import graph; graph đăng ký "graph sink" qua `workspace.attachGraph()`.

## Checklist thử tay cho M0 (hành vi phải y như mind-map cũ)

```bash
npm install && npm run dev
```

1. Mở thư mục (Chrome/Edge: `showDirectoryPicker`; Firefox/Safari: hộp chọn thư mục) → thấy tiến độ, rồi màn hình Tổng quan.
2. Rê chuột vào node project → hiện bảng thông tin; bấm → vào chi tiết project.
3. Trong project: bấm node → làm nổi bật + bảng thông tin; bấm đúp node mờ (ghost) → nhảy sang project kia, node đó được chọn sẵn.
4. Bật/tắt "Gồm thư viện & mã sinh tự động" → phân tích lại.
5. Đổi hình dạng một loại node ở chú thích → node đổi ngay; tải lại trang vẫn giữ.
6. "Dừng sắp xếp" / "Sắp xếp lại" / "Vừa khung"; nút lọc node 3 trạng thái.
7. "Báo cáo" → hiện Markdown, "Chép Markdown" hoạt động.
8. Mở thư mục thứ hai khi đang có sơ đồ → sơ đồ cũ được xoá sạch, không lỗi.

## Checklist thử tay cho M1

Lần này **bắt buộc thử cả hai chế độ mở thư mục** (Chrome/Edge và Firefox/Safari), vì thay đổi chính là chỗ gỡ tên thư mục gốc.

```bash
npm test          # 27 test cho core/
npm run dev
```

1. Chạy lại checklist M0 (8 bước) — mọi thứ phải y như cũ. Với cùng một thư mục, **số file / node / liên kết** ở thanh trên phải bằng số đã thấy ở M0.
2. Mở một thư mục, bấm một node file, rồi trong Console (chỉ có khi `npm run dev`):
   ```js
   explorer.sel.filePath                                   // vd. 'src/App.vue' — KHÔNG có tên thư mục gốc phía trước
   await explorer.ws.readFile(explorer.sel.filePath)       // trả về nội dung file
   explorer.ws.hasFile(explorer.sel.filePath)              // true
   await explorer.ws.statFile(explorer.sel.filePath)       // { name, ext, size, … }
   explorer.ws.filePaths().length                          // số file nguồn đang giữ
   ```
3. Các lỗi có mã rõ ràng:
   ```js
   await explorer.ws.readFile('khong-co.js').catch((e) => e.code)   // 'not-found'
   await explorer.ws.readFile('anh.png').catch((e) => e.code)       // 'binary'
   await explorer.ws.readFile(explorer.sel.filePath, { maxSize: 10 }).catch((e) => e.code) // 'too-large'
   ```
4. Làm lại bước 2 ở trình duyệt còn lại (đường dẫn kiểu `webkitRelativePath`): `filePath` vẫn phải không có tên thư mục gốc và `readFile` vẫn trả về nội dung.
5. Bật/tắt "Gồm thư viện & mã sinh tự động" → phân tích lại (dùng lại danh sách file của SourceFS), rồi `readFile` vẫn hoạt động.
6. Mở thư mục thứ hai: `explorer.ws.filePaths()` chỉ còn file của thư mục mới.

## Checklist thử tay cho M2

Đã thử tay và qua (lịch sử).

```bash
npm install
npm test
npm run dev
```

1. Chạy lại checklist M0 nhanh (mở thư mục → Tổng quan → vào project): sơ đồ phải y như cũ khi chưa mở editor.
2. Trong một project, **bấm một node file** → panel bên phải mở ra, hiện đường dẫn, "ngôn ngữ · kích thước" và mã có tô màu cú pháp. Lần đầu có thể thấy "Đang đọc file…" một lúc (đang tải Monaco), các lần sau gần như tức thì. Mở thử các loại: `.cs`, `.js`/`.ts`, `.vue`, `.css`, `.json`.
3. Bấm node khác → đổi file. Cuộn file A xuống giữa, sang file B, rồi quay lại A → **phải về đúng chỗ đã cuộn**.
4. **Kéo thanh chia đôi**: sơ đồ co giãn mượt, không bị méo hay trống; kéo hết cỡ vẫn còn một phần sơ đồ; tải lại trang thì độ rộng được nhớ.
5. **"Ẩn comment"**: bật thì comment biến mất, tắt thì trở lại; nút mờ đi với `.md`, `.json`, `.csproj`. File trên đĩa không đổi.
6. **Đóng/mở**: ✕ đóng panel (sơ đồ vẫn giữ node đang chọn và sơ đồ giãn ra lại đủ rộng); nút **Mã nguồn** trên thanh trên mở lại; bấm lại đúng node đang chọn cũng mở lại.
7. Bấm vào khoảng trống của sơ đồ (bỏ chọn) và đổi qua lại Tổng quan / project → panel **vẫn giữ file đang xem**.
8. Node của project khác (ghost, nét mờ) → mở được file; node endpoint / route / thư viện ngoài → **không** làm đổi panel.
9. Mở thư mục khác (hoặc đổi "Gồm thư viện…") → panel tự đóng.
10. Trình duyệt thứ hai (Firefox/Safari, kiểu `webkitdirectory`): bước 2 vẫn mở đúng file.
11. Mở Console (F12): không có lỗi đỏ, nhất là dạng *"Could not create web worker"* hay *"MonacoEnvironment"*.
12. **`npm run build` rồi `npm run build:single`**, mở file build ra và mở một file mã nguồn. Đây là chỗ rủi ro nhất (xem bên dưới).

## Ghi chú build (từ M2.2)

- `viteSingleFile` đã bị tắt trong `vite.plugins.js` (do bạn sửa) và giữ `vite-plugin-monaco-editor`: build chạy được nhưng cho **nhiều file** (`index.html` + `assets/` + worker của Monaco), phải phục vụ qua http (`npm run preview` hoặc web server tĩnh); mở thẳng bằng file:// không chạy.
- Nhúng worker bằng `?worker&inline` (thử ở M2.1) vẫn build lỗi nên đã bỏ.
- `vite.config.single.js` hiện dùng cùng plugin nên cũng ra nhiều file (vào `dist-single/`); không còn ý nghĩa "một file".
- Sigma tự co giãn theo vùng chứa qua `gs.resize()` (ResizeObserver) — đã thử tay ở M2, hoạt động.

## Checklist thử tay cho M3 (đã thử tay, qua — lịch sử)

```bash
npm install     # không có thư viện mới ở M3
npm test        # 52 test
npm run dev
```

**Danh sách file và bộ lọc**

1. Mở thư mục → **sidebar trái** hiện ra với số file ở đầu và các **chip đuôi file có đếm**; sơ đồ và editor vẫn như M2. Nút **Danh sách file** đóng/mở; kéo thanh chia đôi bên trái đổi độ rộng (nhớ sau khi tải lại, sơ đồ luôn còn chỗ).
2. Bấm chip: chọn thêm / bỏ đuôi; **Alt + bấm** = chỉ chọn đuôi đó; "Tất cả" đặt lại.
3. Bấm một file trong danh sách → editor mở file. Nếu đang ở Tổng quan hoặc project khác, sơ đồ **tự chuyển sang đúng project**, node được chọn và camera căn vào node. File không có node (`README.md`, `.csproj`, `.json`) → chỉ mở editor, sơ đồ giữ nguyên.
4. Bấm một node trên sơ đồ → danh sách **cuộn tới file đó**, hàng có viền xanh.

**Tìm kiếm** (gõ và đợi khoảng 0,25 giây, hoặc nhấn Enter)

5. Gõ tên file (vd. `app vue`): mục **Tên file** hiện tức thì, mọi từ phải khớp, tên bắt đầu bằng từ khoá xếp trên.
6. Gõ tên một class / hàm: mục **Symbol**; bấm → mở file và **nhảy đúng dòng khai báo** (dòng nhấp nháy vàng khoảng 2 giây).
7. Gõ một chuỗi có trong code: mục **Nội dung** hiện dần ("Đang quét x/y"), mỗi file có số lần khớp và dòng trích dẫn có chữ tô vàng; bấm → editor nhảy tới dòng khớp đầu tiên và **tô sáng mọi chỗ khớp** (cả trên thanh cuộn).
8. **Làm nổi bật trên sơ đồ**: khi có truy vấn, node có kết quả nổi lên, còn lại mờ đi; ở Tổng quan là các project có kết quả. Xoá truy vấn → trở lại bình thường.
9. Gõ tiếp khi đang quét → quét cũ dừng, kết quả không bị lẫn. **Quan trọng**: mở một project lớn và gõ tìm ngay khi sơ đồ còn đang sắp xếp — sơ đồ **không được đứng hình**.
10. Phím: **Ctrl+K** (cả khi con trỏ đang ở editor) mở Explorer và focus ô tìm; ↑ ↓ chọn hàng; Enter mở; Esc xoá ô tìm.
11. Bật "Ẩn comment", rồi bấm một kết quả có số dòng → tự tắt ẩn comment và vẫn nhảy đúng dòng.
12. Dự án lớn: danh sách cuộn mượt; mở thư mục khác → danh sách, bộ lọc và ô tìm được đặt lại.
13. Firefox / Safari (`webkitdirectory`): kết quả vẫn mở đúng file. Console (F12) không có lỗi đỏ.

## Ghi chú về M3 (đã thử tay, qua)

- Các API từng ghi là "chưa kiểm chứng" (`getNodeDisplayData` + `camera.animate`, `findMatches` + `createDecorationsCollection`) đã hoạt động khi thử tay.
- Tìm nội dung chạy chung Worker với bố cục; nếu sau này thấy bố cục chậm khi đang quét thì tách worker riêng.
- Chưa có: regex, tìm nguyên từ, phân biệt hoa thường, giới hạn phạm vi theo thư mục. Danh sách tên file chỉ hiện 500 kết quả tốt nhất.

## Checklist thử tay cho M4

```bash
npm test        # 62 test
npm run dev
```

1. Mở một file **có node** (một component, một class…). Dưới tên file xuất hiện **dải mới** với ba nút kèm số: *Định nghĩa · Dùng · Được dùng bởi* (nút có số 0 bị mờ). File không có node (README, `.json`, `.csproj`) → không có dải.
2. **Định nghĩa**: bấm → danh sách symbol của file kèm số dòng; bấm một mục → editor nhảy đúng dòng và dòng nhấp nháy vàng.
3. **Dùng**: bấm → các file mà file này dùng; mỗi mục có loại quan hệ (import, render, kế thừa, tiêm DI, gọi API…), tên được dùng và đường dẫn.
   - Bấm mục → mở file đó **đúng dòng định nghĩa** của tên được dùng, và tên đó được tô sáng. (Với `import` của JS/TS không có tên symbol → mở đầu file: đây là giới hạn của dữ liệu.)
   - Dưới mục có "dùng ở dòng 12 40": bấm số → nhảy tới dòng đó **ngay trong file đang xem**.
4. **Được dùng bởi**: bấm → các file đang dùng file này; bấm mục → mở file đó **đúng dòng nó dùng file này**. Thử với file ở project khác: sơ đồ tự chuyển project, chọn node, editor nhảy dòng.
5. **Gọi API**: mở một file front-end có gọi API → mục *Dùng* có file controller ở back-end (kể cả project khác) với tên kiểu `GET /…` và dấu ≈ (suy đoán); bấm → mở file back-end tại dòng định nghĩa endpoint. Mở chính file controller đó → *Được dùng bởi* liệt kê file front-end gọi nó.
6. Thư viện ngoài hiện dạng "+ n thư viện ngoài" (rê chuột để xem tên).
7. Đóng danh sách: bấm ra ngoài, nhấn Esc, hoặc chọn một mục. Danh sách phủ lên editor (không làm editor co giãn) và **không bị thanh cuộn / minimap của Monaco che**.
8. Chuyển nhanh qua lại nhiều file → dải luôn khớp với file đang xem, không hiện dữ liệu của file trước.
9. Bật "Ẩn comment" rồi bấm một mục có số dòng → tự tắt ẩn comment và nhảy đúng dòng.
10. Mở một project lớn khi sơ đồ còn đang sắp xếp rồi mở dải → dải vẫn phản hồi và **sơ đồ không bị đứng** (truy vấn quan hệ không huỷ bố cục).
11. Console (F12) không có lỗi đỏ.

## Điểm cần chú ý của M4

- **Dữ liệu thật của analyzer chưa chạy được ở phía tôi** (máy tôi không có các thư viện phân tích): test dùng đồ thị giả dựng theo đúng cấu trúc cạnh trong `05-pass2-resolve.js` / `06-build-graph.js` (`kind`, `labels`, `locs: { path, line }`, cạnh `exposes`). Nếu một quan hệ nhảy sai dòng, gửi tôi tên hai file và loại quan hệ.
- Quan hệ chỉ chính xác bằng bộ phân tích: nhiều cạnh là suy đoán (dấu ≈).
- Cạnh có hướng ngược (`emits`, `provides`) được liệt kê theo đúng hướng trong đồ thị, giống chữ "Dùng / Được dùng bởi" trên bảng thông tin của sơ đồ.
