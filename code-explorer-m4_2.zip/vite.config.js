import { defineConfig } from 'vite'
import { explorerPlugins } from './vite.plugins.js'

export default defineConfig({
  plugins: explorerPlugins(),
})
