<template>
  <div class="app-container">
    <TopBar />
    <div ref="splitEl" class="main-split">
      <GraphView />
      <template v-if="layout.editorOpen">
        <SplitHandle @drag="onDrag" />
        <EditorPanel :style="{ width: layout.editorWidth + 'px' }" />
      </template>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import TopBar from './components/TopBar.vue'
import SplitHandle from './components/SplitHandle.vue'
import GraphView from './features/graph/GraphView.vue'
import EditorPanel from './features/editor/EditorPanel.vue'
import { useLayoutStore } from './stores/layout'

const layout = useLayoutStore()
const splitEl = ref(null)

// Editor nằm bên phải: độ rộng = mép phải vùng chứa − vị trí con trỏ
function onDrag(clientX) {
  const rect = splitEl.value.getBoundingClientRect()
  layout.setEditorWidth(rect.right - clientX, rect.width)
}
</script>

<style scoped>
.app-container {
  display: flex;
  flex-direction: column;
  width: 100vw;
  height: 100vh;
  background-color: #f8f9fa;
}

.main-split {
  flex: 1;
  display: flex;
  min-height: 0;
}
</style>
