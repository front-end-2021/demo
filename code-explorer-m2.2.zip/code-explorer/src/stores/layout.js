// stores/layout.js — Bố cục giao diện: panel editor bên phải sơ đồ.
//
// Panel tự mở khi người dùng CHỌN một node file (selection.tick tăng; chọn lại đúng node đang chọn
// cũng mở lại), đóng bằng nút ✕ / nút "Mã nguồn", và tự đóng khi mở thư mục khác.

import { defineStore } from 'pinia'
import { ref, watch } from 'vue'
import { useSelectionStore } from './selection'
import { useWorkspaceStore } from './workspace'
import { clampEditorWidth, EDITOR_DEFAULT_WIDTH } from '../features/editor/panel-width'

const WIDTH_KEY = 'code-explorer.editorWidth'

function loadWidth() {
  try {
    const n = Number(localStorage.getItem(WIDTH_KEY))
    return n > 0 ? clampEditorWidth(n, window.innerWidth) : EDITOR_DEFAULT_WIDTH
  } catch {
    return EDITOR_DEFAULT_WIDTH
  }
}

export const useLayoutStore = defineStore('layout', () => {
  const selection = useSelectionStore()
  const workspace = useWorkspaceStore()

  const editorOpen = ref(false)
  const editorWidth = ref(loadWidth())
  /** Chỉ ảnh hưởng cách HIỂN THỊ (stripComments), không đổi file. */
  const hideComments = ref(false)

  watch(() => selection.tick, () => {
    if (selection.filePath) editorOpen.value = true
  })

  // Mở thư mục khác (hoặc phân tích lại) → bỏ file của lần trước
  watch(() => workspace.hasData, (has) => {
    if (!has) editorOpen.value = false
  })

  function toggleEditor() {
    editorOpen.value = !editorOpen.value
  }

  function setEditorWidth(width, containerWidth = window.innerWidth) {
    editorWidth.value = clampEditorWidth(width, containerWidth)
    try { localStorage.setItem(WIDTH_KEY, String(editorWidth.value)) } catch { /* bỏ qua */ }
  }

  return { editorOpen, editorWidth, hideComments, toggleEditor, setEditorWidth }
})
