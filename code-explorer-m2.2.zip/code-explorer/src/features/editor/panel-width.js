// features/editor/panel-width.js — Giới hạn độ rộng panel editor, luôn chừa chỗ cho sơ đồ
// (Sigma ném lỗi nếu vùng vẽ rộng 0, nên sơ đồ không bao giờ được bị ép về 0).

export const EDITOR_MIN_WIDTH = 320
export const EDITOR_DEFAULT_WIDTH = 560
export const GRAPH_MIN_WIDTH = 280

/** @param {number} width độ rộng mong muốn  @param {number} containerWidth độ rộng vùng chứa cả sơ đồ lẫn editor */
export function clampEditorWidth(width, containerWidth) {
  const max = Math.max(EDITOR_MIN_WIDTH, containerWidth - GRAPH_MIN_WIDTH)
  const w = Number.isFinite(width) ? width : EDITOR_DEFAULT_WIDTH
  return Math.round(Math.min(max, Math.max(EDITOR_MIN_WIDTH, w)))
}
